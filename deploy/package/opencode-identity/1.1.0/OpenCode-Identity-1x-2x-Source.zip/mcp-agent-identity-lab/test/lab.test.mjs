import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile, rm, chmod } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import { execFile, spawn } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { Effect } from 'effect';
import { setupDemo, generatePlugin, registerIdentity } from '../lib/generator.mjs';
import { createIdentityServer } from '../lib/server.mjs';
import { verifyTerminal, loadTerminalConfig, callTool } from '../lib/client.mjs';
import { makeProof, HEADER } from '../lib/proof.mjs';
import { readJSON, protectedRead } from '../lib/files.mjs';
import plugin from '../lib/opencode-plugin.mjs';
async function fixture(){
 const root=await mkdtemp(path.join(tmpdir(),'identity-lab-'));const workspace=path.join(root,'workspace');await mkdir(workspace,{mode:0o700});
 const demo=await setupDemo({directory:path.join(root,'data'),workspaceRoot:workspace});const audit=[];
 const server=createIdentityServer({registryFile:demo.registryFile,audit:e=>audit.push(e)});const url=await server.start(0);
 const config=await readJSON(demo.configFile);config.serverUrl=url;await writeFile(demo.configFile,JSON.stringify(config));
 const context=(agent,ask=()=>Effect.void)=>({agent,sessionID:'test-session',directory:workspace,abort:new AbortController().signal,ask});
 return {root,workspace,demo,server,audit,config,url,context,async close(){await server.close();await rm(root,{recursive:true,force:true});}};
}
const rawRPC=()=>Buffer.from(JSON.stringify({jsonrpc:'2.0',id:'probe',method:'tools/call',params:{name:'whoami',arguments:{}}}));
async function send(f,body,proof){return fetch(f.url,{method:'POST',headers:{'Content-Type':'application/json',[HEADER]:proof},body});}
test('real HTTP MCP confirms two UUIDs and injects identity into every tool method',async()=>{
 const f=await fixture();try{
  const [a,b]=await Promise.all(['build','plan'].map(name=>verifyTerminal(f.demo.configFile,name)));
  assert.equal(a.verified,true);assert.equal(b.verified,true);assert.notEqual(a.identity.uuid,b.identity.uuid);
  const config=await loadTerminalConfig(f.demo.configFile);
  const add=await callTool(config,config.agents[0],'add',{a:12,b:30});assert.equal(add.structuredContent.sum,42);assert.equal(add.structuredContent.identity.uuid,a.identity.uuid);
  await assert.rejects(callTool(config,config.agents[0],'whoami',{uuid:b.identity.uuid}),/Invalid tool arguments/);
  assert.ok(f.audit.some(e=>e.uuid===a.identity.uuid&&e.tool==='add'));
  const health=await fetch(new URL('/health',f.url));assert.equal(health.status,200);
 }finally{await f.close();}
});
test('rejects unsigned calls, cross-Agent keys, body/name/UUID tampering, expired proofs and replays',async()=>{
 const f=await fixture();try{
  const agent=f.config.agents[0],other=f.config.agents[1],privateKey=await protectedRead(agent.privateKeyFile),body=rawRPC();
  const issue=(extra={})=>makeProof({uuid:agent.uuid,agentName:agent.agentName,privateKey,url:f.url,body,...extra});
  assert.equal((await fetch(f.url,{method:'POST',headers:{'Content-Type':'application/json'},body})).status,401);
  const proof=issue();assert.equal((await send(f,body,proof)).status,200);assert.equal((await send(f,body,proof)).status,401);
  assert.equal((await send(f,Buffer.from(body.toString().replace('whoami','add')),issue())).status,401);
  assert.equal((await send(f,body,issue({uuid:other.uuid,agentName:other.agentName}))).status,401);
  assert.equal((await send(f,body,issue({agentName:'plan'}))).status,401);
  assert.equal((await send(f,body,issue({now:Math.floor(Date.now()/1000)-60}))).status,401);
  assert.equal((await send(f,body,issue({now:Math.floor(Date.now()/1000)+60}))).status,401);
  const parts=issue().split('.'),claims=JSON.parse(Buffer.from(parts[1],'base64url'));claims.agent='plan';parts[1]=Buffer.from(JSON.stringify(claims)).toString('base64url');
  assert.equal((await send(f,body,parts.join('.'))).status,401);
 }finally{await f.close();}
});
test('revoking a public registry entry takes effect without restarting the server',async()=>{
 const f=await fixture();try{
  await verifyTerminal(f.demo.configFile,'build');const registry=await readJSON(f.demo.registryFile);registry.agents[0].enabled=false;
  await writeFile(f.demo.registryFile,JSON.stringify(registry));await assert.rejects(verifyTerminal(f.demo.configFile,'build'),/HTTP 401/);
  assert.equal((await verifyTerminal(f.demo.configFile,'plan')).verified,true);
 }finally{await f.close();}
});
test('real OpenCode plugin captures host Agent, honors approval/cancellation and discards forged identity arguments',async()=>{
 const f=await fixture();try{
  const hooks=await plugin.server({directory:f.workspace},{configFile:f.demo.configFile});let approvals=0;
  const before=f.audit.length;
  await assert.rejects(hooks.tool.identity_whoami.execute({},f.context('build',()=>Effect.sync(()=>{approvals++;throw new Error('DENIED');}))),/DENIED/);
  assert.equal(approvals,1);assert.equal(f.audit.length,before);
  await assert.rejects(hooks.tool.identity_whoami.execute({},f.context('unknown')),/not registered/);assert.equal(f.audit.length,before);
  const abort=new AbortController();abort.abort();await assert.rejects(hooks.tool.identity_whoami.execute({},{...f.context('build'),abort:abort.signal}));assert.equal(f.audit.length,before);
  const [a,b]=await Promise.all([hooks.tool.identity_whoami.execute({uuid:f.config.agents[1].uuid,agentName:'plan'},f.context('build')),hooks.tool.identity_echo.execute({text:'hello'},f.context('plan'))]);
  assert.equal(JSON.parse(a).identity.uuid,f.config.agents[0].uuid);assert.equal(JSON.parse(b).identity.uuid,f.config.agents[1].uuid);
  const generated=await import(pathToFileURL(f.demo.pluginFile).href);assert.equal(generated.default.id,plugin.id);
 }finally{await f.close();}
});
test('generator does not overwrite identities; public enrollment is idempotent; unsafe key permissions fail closed',async()=>{
 const f=await fixture();try{
  await assert.rejects(setupDemo({directory:f.demo.directory,workspaceRoot:f.workspace}),/exist/i);
  await assert.rejects(generatePlugin(f.demo.configFile,path.join(f.workspace,'plugin')),/outside/);
  const enrollment=path.join(f.demo.directory,'agent-1/enrollment.json');
  assert.equal((await registerIdentity(f.demo.registryFile,enrollment)).existing,true);
  const publicData=await readFile(f.demo.registryFile,'utf8');assert.ok(!publicData.includes('PRIVATE KEY'));assert.ok(!publicData.includes('privateKeyFile'));
  if(process.platform!=='win32'){await chmod(f.config.agents[0].privateKeyFile,0o644);await assert.rejects(verifyTerminal(f.demo.configFile,'build'),/owner-only/);}
 }finally{await f.close();}
});
test('terminal CLI works independently from OpenCode and produces a real verification response',async()=>{
 const f=await fixture();try{
  const exec=promisify(execFile);const r=await exec(process.execPath,['bin/lab.mjs','verify','--config',f.demo.configFile,'--agent','build'],{cwd:path.resolve(import.meta.dirname,'..')});
  assert.equal(JSON.parse(r.stdout).verified,true);assert.ok(!r.stdout.includes('PRIVATE KEY'));
 }finally{await f.close();}
});

test('packaged server CLI starts as a separate process and accepts a terminal call with an args file',async()=>{
 const f=await fixture();let child,closed;
 try{
  child=spawn(process.execPath,['bin/lab.mjs','server','--registry',f.demo.registryFile,'--port','0'],{cwd:path.resolve(import.meta.dirname,'..'),stdio:['ignore','pipe','pipe'],windowsHide:true});
  closed=new Promise(resolve=>child.once('close',resolve));
  const url=await new Promise((resolve,reject)=>{
   let output='';const timer=setTimeout(()=>reject(new Error('Server CLI startup timeout')),10000);
   child.once('error',e=>{clearTimeout(timer);reject(e);});
   child.once('exit',()=>{clearTimeout(timer);reject(new Error('Server CLI exited before startup'));});
   child.stdout.on('data',chunk=>{output+=chunk;const match=output.match(/"listening":\s*"([^"]+)"/);if(match){clearTimeout(timer);resolve(match[1]);}});
  });
  f.config.serverUrl=url;await writeFile(f.demo.configFile,JSON.stringify(f.config));
  const argsFile=path.join(f.demo.directory,'add.json');await writeFile(argsFile,'\uFEFF'+JSON.stringify({a:12,b:30}));
  const r=await promisify(execFile)(process.execPath,['bin/lab.mjs','call','--config',f.demo.configFile,'--agent','build','--tool','add','--args-file',argsFile],{cwd:path.resolve(import.meta.dirname,'..')});
  assert.equal(JSON.parse(r.stdout).structuredContent.sum,42);
 }finally{if(child){child.kill('SIGTERM');await closed;}await f.close();}
});

test('OpenCode 1.x Promise approval is awaited, rejects without requests, and supports cancellation',async()=>{
 const f=await fixture();try{
  const hooks=await plugin.server({directory:f.workspace},{configFile:f.demo.configFile});let approvals=0;
  const ctx=f.context('build',async()=>{approvals++;});
  const result=await hooks.tool.identity_whoami.execute({},ctx);assert.equal(JSON.parse(result).identity.uuid,f.config.agents[0].uuid);assert.equal(approvals,1);
  const before=f.audit.length;
  await assert.rejects(hooks.tool.identity_whoami.execute({},f.context('build',async()=>{throw new Error('PROMISE_DENIED');})),/PROMISE_DENIED/);
  assert.equal(f.audit.length,before);
  const controller=new AbortController();let enter;
  const entered=new Promise(resolve=>{enter=resolve;});
  const running=hooks.tool.identity_whoami.execute({},{...f.context('build',()=>{enter();return new Promise(()=>{});}),abort:controller.signal});
  await entered;controller.abort();await assert.rejects(running);assert.equal(f.audit.length,before);
 }finally{await f.close();}
});

test('old 1.x callable/string entry requires explicit read-only opt-in when ask is absent',async()=>{
 const f=await fixture();try{
  const context={agent:'build',sessionID:'old-v1-session',messageID:'old-message',abort:new AbortController().signal};
  const before=f.audit.length;let hooks=await plugin({directory:f.workspace},{configFile:f.demo.configFile});
  await assert.rejects(hooks.tool.identity_whoami.execute({},context),/legacyReadOnly/);assert.equal(f.audit.length,before);
  f.config.legacyReadOnly=true;await writeFile(f.demo.configFile,JSON.stringify(f.config));
  const generated=await import(pathToFileURL(f.demo.pluginFile).href);assert.equal(typeof generated.default,'function');
  hooks=await generated.default({directory:f.workspace});
  const result=await hooks.tool.identity_whoami.execute({agentName:'plan'},context);
  assert.equal(typeof result,'string');assert.equal(JSON.parse(result).identity.agentName,'build');
 }finally{await f.close();}
});

async function v2Host(f, overrides={}) {
 const definitions=new Map(),permissions=[];let disposed=false;
 const host={app:{version:'2.2.5'},location:{directory:f.workspace},options:{configFile:f.demo.configFile},
  session:{async get({sessionID}){return {id:sessionID,location:{directory:f.workspace}};}},
  permission:{async assert(input){permissions.push(input);}},
  tool:{async transform(callback){callback({add(def){definitions.set(def.name,def);}});return {async dispose(){disposed=true;}};}},...overrides};
 const module=await import(pathToFileURL(path.join(f.demo.entries.v2,'index.js')).href);
 const cleanup=await module.default.setup(host);
 const context=(agent)=>({agent,sessionID:`v2-${agent}`,messageID:`message-${agent}`,id:`call-${agent}`,signal:new AbortController().signal,async progress(){}});
 return {host,definitions,permissions,cleanup,context,get disposed(){return disposed;}};
}

test('OpenCode 2.x native setup registers JSON-schema tools, asserts permission and keeps concurrent identities separate',async()=>{
 const f=await fixture();try{
  const host=await v2Host(f);assert.equal(host.definitions.size,3);
  const [a,b]=await Promise.all([
   host.definitions.get('identity_whoami').execute({agentName:'plan',uuid:f.config.agents[1].uuid},host.context('build')),
   host.definitions.get('identity_add').execute({a:5,b:7},host.context('plan'))
  ]);
  assert.equal(JSON.parse(a.content).identity.uuid,f.config.agents[0].uuid);
  assert.equal(JSON.parse(b.content).identity.uuid,f.config.agents[1].uuid);assert.equal(JSON.parse(b.content).sum,12);
  assert.equal(host.permissions.length,2);assert.equal(host.permissions[0].source.type,'tool');
  assert.equal(host.definitions.get('identity_whoami').options.codemode,false);
  await host.cleanup();assert.equal(host.disposed,true);
  const fragment=JSON.parse(await readFile(f.demo.fragments.v2,'utf8'));
  assert.ok(fragment.plugins[0].package.endsWith('/opencode-v2'));assert.ok(!fragment.plugin);
  assert.equal(fragment.permissions[0].effect,'ask');assert.equal(fragment.permissions[0].resource,'*');
 }finally{await f.close();}
});

test('OpenCode 2.x denial, cancellation, missing true Agent and foreign session workspace all prevent network calls',async()=>{
 const f=await fixture();try{
  const host=await v2Host(f);const execute=host.definitions.get('identity_whoami').execute,before=f.audit.length;
  host.host.permission.assert=async()=>{throw new Error('V2_DENIED');};
  await assert.rejects(execute({},host.context('build')),/V2_DENIED/);assert.equal(f.audit.length,before);
  await assert.rejects(execute({agent:'build'},host.context(undefined)),/trusted OpenCode/);assert.equal(f.audit.length,before);
  const other=path.join(f.root,'other');await mkdir(other,{mode:0o700});
  host.host.session.get=async({sessionID})=>({id:sessionID,location:{directory:other}});
  await assert.rejects(execute({},host.context('build')),/Unapproved session/);assert.equal(f.audit.length,before);
  host.host.session.get=async({sessionID})=>({id:sessionID,location:{directory:f.workspace}});
  let enter;const entered=new Promise(resolve=>{enter=resolve;});host.host.permission.assert=()=>{enter();return new Promise(()=>{});};
  const controller=new AbortController();const running=execute({},{...host.context('build'),signal:controller.signal});
  await entered;controller.abort();await assert.rejects(running);assert.equal(f.audit.length,before);
 }finally{await f.close();}
});

test('OpenCode 2.x snapshots executing Agent before session lookup/approval awaits',async()=>{
 const f=await fixture();try{
  const host=await v2Host(f);let release;
  host.host.session.get=({sessionID})=>new Promise(resolve=>{release=()=>resolve({id:sessionID,location:{directory:f.workspace}});});
  const context=host.context('build');const running=host.definitions.get('identity_whoami').execute({},context);
  context.agent='plan';context.sessionID='wrong-session';release();
  const result=await running;
  assert.equal(host.permissions[0].agent,'build');assert.equal(host.permissions[0].sessionID,'v2-build');
  assert.equal(JSON.parse(result.content).identity.agentName,'build');
 }finally{await f.close();}
});

test('version classification accepts 1.x and 2.x while rejecting unknown majors and unparseable output',async()=>{
 const {parseOpenCodeVersion,requireMajor}=await import('../lib/opencode-compat.mjs');
 for(const v of ['1.0.142','1.14.30','1.19.5'])assert.equal(parseOpenCodeVersion(v).profile,'v1');
 for(const v of ['2.0.28','opencode v2.2.5','2.2.0-beta.1'])assert.equal(parseOpenCodeVersion(v).profile,'v2');
 assert.equal(parseOpenCodeVersion('3.0.0').supported,false);
 assert.throws(()=>parseOpenCodeVersion('unknown'),/parse/);assert.throws(()=>requireMajor('3'),/major/);
});

test('early OpenCode 2.0 context without permission.assert requires explicit local read-only compatibility',async()=>{
 const f=await fixture();try{
  const before=f.audit.length;
  await assert.rejects(v2Host(f,{app:{version:'2.0.28'},permission:{}}),/legacyReadOnly/);assert.equal(f.audit.length,before);
  f.config.legacyReadOnly=true;await writeFile(f.demo.configFile,JSON.stringify(f.config));
  const host=await v2Host(f,{app:{version:'2.0.28'},permission:{}});
  const result=await host.definitions.get('identity_whoami').execute({},host.context('build'));
  assert.equal(JSON.parse(result.content).identity.uuid,f.config.agents[0].uuid);await host.cleanup();
 }finally{await f.close();}
});

test('generator emits only the requested major and uses the matching loader/config format',async()=>{
 const f=await fixture();try{
  const v1=await generatePlugin(f.demo.configFile,path.join(f.demo.directory,'only-v1'),{opencodeMajor:'1'});
  const v2=await generatePlugin(f.demo.configFile,path.join(f.demo.directory,'only-v2'),{opencodeMajor:'2'});
  assert.deepEqual(Object.keys(v1.entries),['v1']);assert.deepEqual(Object.keys(v2.entries),['v2']);
  const one=JSON.parse(await readFile(v1.fragmentFile,'utf8')),two=JSON.parse(await readFile(v2.fragmentFile,'utf8'));
  assert.ok(one.plugin[0].endsWith('.mjs'));assert.ok(two.plugins[0].package.endsWith('/opencode-v2'));
  assert.equal(typeof(await import(pathToFileURL(v1.pluginFile).href)).default,'function');
  assert.equal(typeof(await import(pathToFileURL(v2.pluginFile).href)).default.setup,'function');
  await assert.rejects(generatePlugin(f.demo.configFile,path.join(f.demo.directory,'unsupported'),{opencodeMajor:'3'}),/major/);
 }finally{await f.close();}
});
