param(
  [string]$Workspace = (Get-Location).Path,
  [string]$DataDirectory = (Join-Path $env:USERPROFILE ('mcp-identity-data-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))),
  [string]$Agents = 'build,plan',
  [int]$Port = 8765,
  [ValidateSet('1','2','both')][string]$OpenCodeMajor = 'both',
  [switch]$LegacyReadOnly
)
$ErrorActionPreference = 'Stop'
$cli = Join-Path $PSScriptRoot 'bin\lab.mjs'
$Workspace = (Resolve-Path -LiteralPath $Workspace).Path
$commandArgs = @($cli, 'demo', '--out', $DataDirectory, '--workspace', $Workspace, '--agents', $Agents, '--port', $Port, '--opencode-major', $OpenCodeMajor)
if ($LegacyReadOnly) { $commandArgs += @('--legacy-readonly', 'true') }
$result = & node @commandArgs
if ($LASTEXITCODE -ne 0) { throw 'Demo generation failed' }
$data = ($result | Out-String | ConvertFrom-Json)
$startScript = Join-Path $data.directory 'start-server.ps1'
Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-NoExit', '-File', ('"' + $startScript + '"')) | Out-Null
$ready = $false
for ($attempt = 0; $attempt -lt 30; $attempt++) {
  try {
    $null = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$Port/health" -TimeoutSec 1
    $ready = $true
    break
  } catch { Start-Sleep -Milliseconds 500 }
}
if (-not $ready) { throw 'Server did not become ready. Inspect the new server window; the port may be occupied.' }
foreach ($agent in $data.agents) {
  & node $cli verify --config $data.configFile --agent $agent.agentName
  if ($LASTEXITCODE -ne 0) { throw ('Verification failed: ' + $agent.agentName) }
}
Write-Host ('Data directory: ' + $data.directory)
if ($data.fragments.v1) { Write-Host ('OpenCode 1.x fragment: ' + $data.fragments.v1) }
if ($data.fragments.v2) { Write-Host ('OpenCode 2.x fragment: ' + $data.fragments.v2) }
Write-Host 'Merge ONLY the fragment matching your OpenCode major into the existing global config, then restart OpenCode.'
Write-Host 'Stop the server with Ctrl+C in the server window.'
