# 验证记录：独立包 1.1.0

- Linux / Node.js 24.19.0。
- `npm test`：15 组测试，包含原有认证测试、1.x Promise/Effect/早期只读兼容，以及 2.x 原生入口、工具注册、权限拒绝、取消、跨会话工作区和并发身份快照。
- `npm run check:contracts`：以正式 `@opencode/plugin@2.2.5` 类型定义校验实际 V2 实现模块。
- 正式 npm API 核对：1.0.142、1.1.4、1.14.30、1.19.5、2.0.28、2.2.5，详见 COMPATIBILITY.md。
- 最终 ready ZIP 仅包含运行依赖；不包含大型 V2 SDK/TypeScript 开发依赖和可选原生加速器。
- 下载 ZIP 在独立目录解压后重复运行测试。
- 未宣称已完成真实 Windows NTFS 或真实模型宿主的现场验收。
